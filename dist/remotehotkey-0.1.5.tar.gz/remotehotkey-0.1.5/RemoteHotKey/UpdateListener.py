class UpdateListener:

    def __init__(self):
        pass

    def startListening(self):
        pass

    def onEvent(self, jsonStr):
        pass
