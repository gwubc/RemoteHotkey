from __future__ import annotations

import time
import typing

from RemoteHotKey.Controller.Controller import Controller
from RemoteHotKey.State import State

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from RemoteHotKey.Action.ActionManager import ActionManager
    from RemoteHotKey.WebUI.UITemplate import UITemplate
    from RemoteHotKey.OneTimeEvent import OneTimeEvent


class ClientManager:
    EventExpireAfter = 5

    _running = False

    _actionManager: typing.List[ActionManager] = None

    _handledEvent: typing.List[OneTimeEvent] = None

    _controller = None

    def __init__(self):
        self._actionManager = []
        self._handledEvent = []
        self._controller = Controller()
        self._controller.addOnEventObserver(self.updateActionManagerState)

    def setUITemplate(self, uiTemplate: UITemplate):
        self._controller.setUITemplate(uiTemplate)

    def addActionManager(self, actionManager: ActionManager):
        self._actionManager.append(actionManager)

    def removeHandledEvent(self):
        unhandledEvent = []
        for event in self._controller.getState().getEventLog():
            if event in self._handledEvent or (time.time() - event.getTimeStamp()) > self.EventExpireAfter:
                pass
            else:
                unhandledEvent.append(event)
                self._handledEvent.append(event)

        self._controller.getState().clearEventLog()
        for event in unhandledEvent:
            self._controller.getState().addOneTimeEvent(event)

        while len(self._handledEvent) > State.MaxLenOfEventLog:
            self._handledEvent.pop(0)

    def updateActionManagerState(self):
        self.removeHandledEvent()

        for actionManager in self._actionManager:
            actionManager.updateState(self._controller.getState())

    def start(self):
        self._running = True

    def termination(self):
        self._running = False
