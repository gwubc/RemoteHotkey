import json


class OneTimeEvent:
    _name = None
    _timeStamp = None

    def __init__(self, jsonStr=None):
        if jsonStr is not None:
            jsonDic = json.loads(jsonStr)
            self.setFields(jsonDic["name"], jsonDic["timeStamp"])

    def setFields(self, name: str, timeStamp: float):
        self._name = name
        self._timeStamp = timeStamp

    def getName(self) -> str:
        return self._name

    def getTimeStamp(self) -> float:
        return self._timeStamp

    def toJson(self):
        jsonDic = {"name": self._name, "timeStamp": self._timeStamp}
        return json.dumps(jsonDic)

    def __eq__(self, o: object) -> bool:
        return o.__hash__() == self.__hash__()

    def __hash__(self) -> int:
        return hash(self._name + f"{self._timeStamp}")
