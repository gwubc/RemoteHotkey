from __future__ import annotations

import json
import logging
import threading
import time

from RemoteHotKey.State import State

from RemoteHotKey.Controller.UpdateListener import UpdateListener

from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options

from jinja2 import Environment, BaseLoader
from RemoteHotKey.definitions import ROOT_DIR

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from RemoteHotKey.Controller.Controller import Controller


class AblyUpdateListener(UpdateListener):
    _running = False
    _controller = None
    _driver = None

    def __init__(self, controller: Controller, apiKey, channelId):
        super().__init__()
        self._controller = controller

        rtemplate = Environment(loader=BaseLoader()).from_string(
            open(f"{ROOT_DIR}/helper/AblyBridge.html", encoding='utf8').read())
        html_content = rtemplate.render(apiKey=apiKey, channelId=channelId)
        htmlString = "data:text/html;charset=utf-8,{html_content}".format(html_content=html_content)

        options = Options()
        options.headless = True

        self._driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
        self._driver.get(htmlString)
        self._running = True

    def startListening(self):
        def _listen():
            while self._running:
                jsonStr = self._driver.execute_script('return getNewMsgs()')
                if jsonStr != "[]":
                    self.onEvent(jsonStr)
                time.sleep(0.01)

        t = threading.Thread(target=_listen)
        t.daemon = True
        t.start()

    def onEvent(self, jsonStr):
        jsonData = json.loads(jsonStr)
        needPublishUI = False
        timeReceived = 0
        for event in jsonData:
            if event.get("name") == "event" and event.get("data"):
                self._controller.onEvent(event.get("data"))
                try:
                    timeReceived = int(event.get("data").get("time"))
                except ValueError:
                    pass
                needPublishUI = True
            elif event.get("name") == "requestUiUpdate":
                needPublishUI = True
            elif event.get("name") == "uiUpdate":
                pass
        if needPublishUI:
            self.publishUI()
        logging.info(f"Latency: {int(time.time() * 1000) - timeReceived} ms; data: {jsonStr}")

        return

    def publishUI(self):
        self._driver.execute_script(f"publish('uiUpdate', '{json.dumps(self._controller.getJsonDic()['ui'])}')")
        return

    def getState(self) -> State:
        return self._controller.getState()

    def termination(self):
        self._running = False
