from __future__ import annotations

import typing

import RemoteHotKey.definitions
from RemoteHotKey.State import State
from RemoteHotKey.Controller.EventHandler import EventHandler
from RemoteHotKey.Controller.AblyUpdateListener import AblyUpdateListener

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from RemoteHotKey.WebUI.UITemplate import UITemplate
    from RemoteHotKey.Controller.UpdateListener import UpdateListener


class Controller:
    _eventHandler = None
    _state: State = None
    _ui: UITemplate = None
    _onEventObserver: typing.List[typing.Callable[[], None]] = None
    _updateListener: UpdateListener = None

    def __init__(self):
        self._onEventObserver = []
        self._state = State()
        self._eventHandler = EventHandler(self)
        self._updateListener = \
            AblyUpdateListener(self, RemoteHotKey.definitions.apiKey, RemoteHotKey.definitions.channelId)
        self._updateListener.startListening()

    def getState(self):
        return self._state

    def addOnEventObserver(self, callBack: typing.Callable[[], None]):
        self._onEventObserver.append(callBack)

    def onEvent(self, event: typing.Dict, **kwargs):
        self._eventHandler.handle(event, **kwargs)
        self._ui.updateCurrentPageIndex(self._state.getFromStorage(State.Keys.currentPageIndex, 0))
        for callBack in self._onEventObserver:
            callBack()

    # return a json contains ui and state
    def getJsonDic(self):
        return {'state': self._state.toJsonDic(), 'ui': self._ui.getCurrentUIPage().getUI(self._state)}

    def setUITemplate(self, uiTemplate: UITemplate):
        self._ui = uiTemplate

    def getUITemplate(self) -> UITemplate:
        return self._ui
