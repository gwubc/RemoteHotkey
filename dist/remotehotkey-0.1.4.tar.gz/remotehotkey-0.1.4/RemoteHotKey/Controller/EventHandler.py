from __future__ import annotations

import typing

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from RemoteHotKey.Controller.Controller import Controller


class InvalidEventException(Exception):
    pass


class EventHandler:
    _controller = None

    def __init__(self, controller: Controller):
        self._controller = controller

    def handle(self, event: typing.Dict, **kwargs):
        match event.get("type"):
            case None:
                raise InvalidEventException()

            case "button":
                if event.get("identifier") is None:
                    raise InvalidEventException()
                self.handleButtonEvent(event.get("identifier"), **kwargs)

            case "slider":
                if (event.get("identifier") is None) or (event.get("value") is None):
                    raise InvalidEventException()
                self.handleButtonEvent(event.get("identifier"), **kwargs, newValue=event.get("value"))
            case _:
                pass

    def handleButtonEvent(self, identifier, **kwargs):
        for button in self._controller.getUITemplate().getVisibleUIElements():
            if button.getIdentifier() == identifier:
                button.updateState(self._controller.getState(), **kwargs)
