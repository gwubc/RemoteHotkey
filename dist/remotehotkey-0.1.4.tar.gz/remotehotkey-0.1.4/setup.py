from setuptools import setup, find_packages

setup(name='remotehotkey',
      version='0.1.4',
      description='remotehotkey',
      url='',
      author='gw',
      author_email='',
      license='MIT',
      packages=find_packages(),
      include_package_data=True,
      install_requires=[
          'webdriver-manager',
          'selenium',
          "jinja2",
          # optional
          'opencv-python',
          'numpy',
          'mss',
          "pynput",
      ],
      zip_safe=False)
